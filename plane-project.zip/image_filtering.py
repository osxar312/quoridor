from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
from scipy.signal import convolve2d


photo_files = [
    "1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg",
    "plane1.jpg", "plane2.jpg", "plane3.jpg", "plane4.jpg",
]

for number in range(len(photo_files)):
    print(number + 1, photo_files[number])

photo_choice = int(input("Choose a photo number: ")) - 1
img = Image.open(photo_files[photo_choice]).convert("L")
original = np.array(img, dtype=float)

gaussian_kernel = np.array([
    [1, 2, 1],
    [2, 4, 2],
    [1, 2, 1],
]) / 16

box_kernel = np.ones((3, 3)) / 9

sobel_vertical = np.array([
    [-1, 0, 1],
    [-2, 0, 2],
    [-1, 0, 1],
])

sobel_horizontal = np.array([
    [-1, -2, -1],
    [0, 0, 0],
    [1, 2, 1],
])

print("1 Gaussian")
print("2 Box filter")
print("3 Vertical Sobel")
print("4 Horizontal Sobel")
print("5 High-pass")
filter_choice = int(input("Choose a filter number: "))

if filter_choice == 1:
    filtered = convolve2d(original, gaussian_kernel, mode="same")
    filter_name = "Gaussian"
elif filter_choice == 2:
    filtered = convolve2d(original, box_kernel, mode="same")
    filter_name = "Box filter"
elif filter_choice == 3:
    filtered = convolve2d(original, sobel_vertical, mode="same")
    filter_name = "Vertical Sobel"
elif filter_choice == 4:
    filtered = convolve2d(original, sobel_horizontal, mode="same")
    filter_name = "Horizontal Sobel"
else:
    smoothed = convolve2d(original, gaussian_kernel, mode="same")
    filtered = original - smoothed
    filter_name = "Original - Gaussian"

plt.subplot(1, 2, 1)
plt.imshow(original, cmap="gray")
plt.title("Original")

plt.subplot(1, 2, 2)
plt.imshow(filtered, cmap="gray")
plt.title(filter_name)

plt.show()
