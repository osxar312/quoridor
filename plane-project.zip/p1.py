from PIL import Image
import matplotlib.pyplot as plt
import numpy as np


def object_positions(img):
	plt.imshow(img, cmap="gray")
	points = []

	for side in ("left", "right"):
		plt.title(f"Click the {side} point")
		point = plt.ginput(1)[0]
		points.append(np.array(point))

	plt.close()
	return points[0], points[1]


def extract_object(img, half_w=0.7, size=(100, 200)):
	gray = img.convert("L")
	c1, c2 = object_positions(gray)

	angle = np.arctan2(c2[1] - c1[1], c2[0] - c1[0])
	rotated = gray.rotate(np.degrees(angle), expand=False)

	rotation = np.array([
		[np.cos(angle), np.sin(angle)],
		[-np.sin(angle), np.cos(angle)],
	])
	center = np.array([gray.width / 2, gray.height / 2])
	p1 = rotation @ (c1 - center) + center
	p2 = rotation @ (c2 - center) + center

	half_width = np.linalg.norm(p2 - p1) / (2 * half_w)
	midpoint = (p1 + p2) / 2
	half_height = half_width * size[1] / size[0]

	box = (
		int(midpoint[0] - half_width),
		int(midpoint[1] - half_height),
		int(midpoint[0] + half_width),
		int(midpoint[1] + half_height),
	)
	return rotated.crop(box).resize(size)


if __name__ == "__main__":
	photo_files = ["plane1.jpg", "plane2.jpg", "1.jpg", "3.jpg"]

	for number in range(len(photo_files)):
		print(number + 1, photo_files[number])

	choice = int(input("Choisis le numero de la photo : ")) - 1
	img = Image.open(photo_files[choice])
	obj = extract_object(img, half_w=0.9, size=(300, 100))
	plt.imshow(obj, cmap="gray")
	plt.axis("off")
	plt.show()
